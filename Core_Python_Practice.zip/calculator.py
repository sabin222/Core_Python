def add(x:int,y:int)->int:
    return x + y

print("Select operation.")
print("1.Add")
print("2.Subtract")
print("3.Multiply")
print("4.Divide")

choice = input("Enter choice: ")
num1:int = input("Enter first number: ")
num2:int = input("Enter second number: ")
if choice == '1':
   print(add(num1,num2))
elif choice == '2':
   print(f"{num1-num2}")
elif choice == '3':
   print(num1,"*",num2,"=", multiply(num1,num2))
elif choice == '4':
   print(num1,"/",num2,"=", divide(num1,num2))
else:
   print("Invalid input")           

    


        
