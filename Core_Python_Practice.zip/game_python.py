'''Game'''
board=[['*','*','*','*','*','*','*','*','*','*','*','*','*','*','*','*','*','*'],
       ['*',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','*'],
       ['*',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','*'],
       ['*',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','*'],
       ['*',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','*'],
       ['*',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','*'],
       ['*',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','*'],
       ['*','*','*','*','*','*','*','*','*','*','*','*','*','*','*','*','*','*']]

player={'char':'p','attack':10,'life':3,'x_position':3,'y_position':5}
R_enemy={'char':'R','attack':7,'life':2,'x_position':3,'y_position':3}
G_enemy={'char':'G','attack':15,'life':3,'x_position':5,'y_position':5}
B_enemy={'char':'B','attack':20,'life':4,'x_position':7,'y_position':7}
def GameBoard(board:list):
    for li in board:
        for val in li:
            print(val,end='')
        print()



def addMembers(board,player):
    if board[player['x_position']][player['y_position']] == '*':
        return;
    board[player['x_position']][player['y_position']]=player['char']

addMembers(board,player)


GameBoard(board)
    


