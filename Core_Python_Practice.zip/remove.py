''' WAF to ramove all the values of a from the list'''
a=2
li=[1,2,3,4,5,6,7,8,2,2,1]
def remove(a:int, li:list):
    while a in li:
        li.remove(a)
                
    print(li)

remove(a,li)
