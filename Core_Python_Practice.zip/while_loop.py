a=6
while a<=25:
    if a%5==0:
        continue
    print(f'value of a is {a}')
    a+=1
    
