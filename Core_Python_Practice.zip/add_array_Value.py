li1=["name","maru","saru"]
li=["dale"]
def addValue(li:list,li1:list):
    for d in li1:
        li.append(d);
        print(li)
addValue(li1,li);

'''write a function to add all value of second list to first list if only the value is even '''
nam=[2,4,6]
name=[7,8,9,10,11,12]
def addList(nam:list,name:list):
    for d in name:
        if d%2==0:
            nam.append(d);

    print(nam)

addList(nam,name)

'''WFA that takes a list and string that removes all the value starting with the string in the list'''

pop=["cat","dog","cut","mote"]
def delete(pop:list, c:str):
    for s in pop:
        if s.startswith(c):
            pop.remove(s);

    print(pop)
delete(pop,"c");


listing=[5,7,9,10,2,1,3,8,15]
print(listing)
listing.sort(reverse=True)
print(listing)
listing.reverse()
print(listing)
listing.sort()
print(listing)


p=['b','c','a','d']
len(listing)
print(sorted(p))




    
    
